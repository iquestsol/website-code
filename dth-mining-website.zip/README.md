# RockTech Drilling Solutions - Website

A professional, fully responsive business website for a DTH drill bits and hammers manufacturer serving the mining, quarrying, and construction industries.

## Features

- **Single-page design** with smooth scroll navigation
- **Product showcase** with tabbed interface (DTH Hammers, DTH Bits, Top Hammer)
- **Interactive specifications table** with search, filter, and sort functionality
- **Industry applications** grid for mining, quarrying, water well, geothermal, construction
- **Contact form** optimized for B2B mining equipment inquiries
- **Mobile-first responsive design** with hamburger menu
- **SEO optimized** with Schema.org markup, Open Graph, meta tags
- **WhatsApp integration** for quick mining industry communication
- **Performance optimized** with smooth animations and lazy loading ready

## Tech Stack

- HTML5 (semantic, accessible)
- CSS3 (custom properties, grid, flexbox, animations)
- Vanilla JavaScript (no dependencies)
- Font Awesome icons
- Google Fonts (Inter + Oswald)

## File Structure

```
dth-mining-website/
├── index.html          # Main page (all sections)
├── css/
│   └── style.css       # Complete stylesheet
├── js/
│   └── main.js         # All interactivity
└── README.md           # This file
```

## Quick Start

### Option 1: GitHub Pages (Recommended - Free Forever)

1. Create a GitHub account at https://github.com
2. Create a new repository named `yourcompany.github.io`
3. Upload these files to the repository
4. Go to Settings → Pages → Source: main branch
5. Your site is live at `https://yourcompany.github.io`

### Option 2: Netlify (Free, Drag & Drop)

1. Go to https://netlify.com and sign up (free)
2. Drag and drop the `dth-mining-website` folder
3. Your site is live instantly with a Netlify subdomain
4. Optional: Connect custom domain (free with Freenom .tk/.ml)

### Option 3: Local Testing

Simply open `index.html` in your browser. No server required.

## Customization Guide

### 1. Company Information
Edit these in `index.html`:
- Company name: Replace "RockTech" throughout
- Contact details: Phone, email, address (in Contact section and Schema.org)
- WhatsApp number: Update the `wa.me` link
- Social media links: Update LinkedIn, YouTube, Alibaba URLs

### 2. Products & Specifications
- Update product cards in the Products section
- Modify the specifications table data
- Add/remove product categories in the tabs

### 3. Form Handling
The contact form uses Formspree (free tier):
1. Sign up at https://formspree.io
2. Create a new form
3. Replace `YOUR_FORM_ID` in the form action URL
4. Submissions will be emailed to you

### 4. Colors & Branding
Edit CSS variables in `css/style.css`:
```css
:root {
    --primary: #0f2744;      /* Your brand blue */
    --secondary: #c53030;     /* Your accent red */
    --accent: #d69e2e;        /* Your highlight gold */
}
```

### 5. Images
Replace the placeholder sections with actual product photos:
- Hero background: Add a mining/drilling image
- Product cards: Add product photos
- About section: Add factory/facility image

## SEO Features Included

- Semantic HTML5 structure
- Schema.org Organization + Product markup
- Open Graph tags for LinkedIn sharing
- Twitter Card meta tags
- Meta descriptions and keywords
- Proper heading hierarchy (H1 → H6)
- Alt text ready for all images
- Mobile viewport optimization

## Browser Support

- Chrome/Edge (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Mobile browsers (iOS Safari, Chrome Android)

## Performance

- No external JavaScript dependencies
- Minimal external requests (fonts, icons)
- CSS custom properties for efficient theming
- Intersection Observer for scroll animations
- Optimized for Core Web Vitals

## License

This template is free to use for commercial purposes. Modify as needed for your mining equipment business.

---

**Built with precision. Engineered for hard rock.**
